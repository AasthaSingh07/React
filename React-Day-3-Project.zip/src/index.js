import {createRoot} from "react-dom/client";
import App from "./components/app";

var idea = createRoot(document.getElementById("root"));
idea.render(<App/>)