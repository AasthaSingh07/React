import { Component } from "react";
import axios from "axios";
// import "../mystyle.css";   (if we take this in role and remove the style in line 26 then we can get css in action)

class App extends Component{
    state = {
        users: []
    }

  
    componentDidMount(){
        axios.get("https://reqres.in/api/users?page=1")
        .then(res => this.setState({users: res.data.data}))
        .catch(err=> console.log(err))

        

    }
    render(){
        return <div>
            <h1>Ajax | API Call</h1>
            <hr />
            <ol> 
                {/* {this is javaScript way} */}
                {this.state.users.map( val=> <li className="list" key = {val.id} style={{ border: val.id%2===0 ? '2px solid red' : '2px solid brown', padding: "10px", margin: "10px"}}><img src={val.avatar} alt=""/>{val.first_name+" "+val.last_name }</li>)}
            </ol>
        </div>
    }
}

export default App;