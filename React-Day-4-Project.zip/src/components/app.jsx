import React from 'react'
import { useState, useReducer } from 'react';


let reducerFun = (state, action) => {
    switch(action.type){
        case "CHANGE": return {...state, [action.field]: action.value}
        default: return state;
    }

}


let App = () => {
    let [store, dispatch] = useReducer(reducerFun, {name: "", age: 0, email:"", phoneno: ""})
    let [issubmitted, setIsSubmitted] = useState(false)

    let ChangeHandler = (e) => {
        let {name, value} = e.target;
        dispatch({type: "CHANGE", field: name, value})
    }

    let SubmitHandler = (e) =>{
        e.preventDefault();
        // console.log(store);
        setIsSubmitted(true);
    }
  return (
    <div style= {{padding:"2px", margin:"10px"}}>
        <form onSubmit={SubmitHandler}>
            <div>
                <label htmlFor='' > Name  <input type="text" name="name" value={store.name} onChange={ChangeHandler}/>
                </label>
            </div>
            <br />
            <div>
                <label htmlFor=''> Age <input type="number" name="age" value={store.age} onChange={ChangeHandler}/>
                </label>
            </div>
            <br />
            <div>
                <label htmlFor=''> Email <input type="email" name="email" value={store.email} onChange={ChangeHandler}/>
                </label>
            </div>
            <br />
            <div>
                <label htmlFor=''> Phoneno <input type="text" name="phoneno" value={store.phoneno} onChange={ChangeHandler}/>
                </label>
            </div>
            <br />
            <button type="submit">Submit</button>
        </form>
        <hr />
        {issubmitted && store.name && store.age && store.email && store.phoneno && (
            <div style = {{border: "2px solid black", padding: "2px", margin: "5px"}}>
                <h2>Form Details: </h2>
                <p>Name is: {store.name}</p>
                <p>Age is: {store.age}</p>
                <p>Email is: {store.email}</p>
                <p>Phoneno is: {store.phoneno}</p>
            </div>
        )}
    </div>
  )
}

export default App;
