let config = {
    port: 5050,
    host: "localhost",
    dbuser : "admin",
    dbpass : "5APFAvX8nO25fBP3",
    dbname : "valtechDB",
    dbstring: "4dsgglf"
}

module.exports = config;