import { Component } from "react";

class Header extends Component{
    render(){
        // return this.props.valtech;
        return this.props.children;
    }

}

export default Header