import {Component} from "react"
import Header from "./Header";
import Navbar from "./Navbar";
import Main from "./Main";
import Footer from "./Footer";

class App extends Component{
    render(){
        return <div>
            <div className="container"><Header /></div>
            <div className="container"><Navbar /></div>
            <Main />
            <Footer />
            

        </div>
    }
}

export default App;