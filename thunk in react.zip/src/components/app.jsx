import React, { Component } from 'react'
import ClassHero from './classhero.component'
import { Provider } from 'react-redux';
import store from '../redux/store.js';
import FunHeroComponent from './funhero.component';

class App extends Component{
    render(){
        return <div>
            <Provider store={store}>
                <ClassHero/>
                    <FunHeroComponent/>
            </Provider>
        </div>
    }
}

export default App;
