
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { getUsers } from '../redux/actions/hero.actions'

class ClassHero extends Component {
  componentDidMount() {
    this.props.dispatch(getUsers());
  }

  render() {
    const {users} = this.props;

    return (
      <div style={{border: "5px dotted black"}}>
          <ol>
            {users.map(({id, avatar, first_name}) => (
              <li key={id}><img src={avatar} alt=""/>{first_name}</li>
            ))}
          </ol>
      </div>
    );
  }
}

// Map the Redux state to the component's props
const mapStateToProps = (state) => ({
  users: state.users,
});

// Connect the component to the Redux store
export default connect(mapStateToProps)(ClassHero);

