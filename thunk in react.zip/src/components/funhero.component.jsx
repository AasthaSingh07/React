
import { useDispatch, useSelector} from "react-redux"
import { getUsers } from '../redux/actions/hero.actions'
import { useEffect } from "react"


let FunHeroComponent = () =>{
    const { users } = useSelector((state) => state);
      let dispatch = useDispatch();
      useEffect(()=>{
        dispatch(getUsers())
      },[dispatch])
    
        return <div style={{border: "2px solid red"}}>
            <ul>
                {users.map(({id, first_name, avatar})=> <li key={id}><img src={avatar} alt=""/>{first_name}</li>)}
            </ul>
        </div>
    }

export default FunHeroComponent;

   
