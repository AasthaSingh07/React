import { createStore, applyMiddleware } from "redux"; // Correct import
import thunkMiddleware from "redux-thunk";
import reducer from "./reducers/hero.reducer"; // Adjust the import based on your file structure

const store = createStore(reducer, applyMiddleware(thunkMiddleware)); // Corrected createStore and applyMiddleware

export default store;