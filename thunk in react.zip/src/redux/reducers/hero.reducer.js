import { GET_USERS_DATA, GET_USERS_ERROR, GET_USERS_REQUEST } from "../types/hero.types"


let initialState = {
    loading: true,
    users: [],
    error: '',
}

 const reducer = (state = initialState, action) => {
    switch (action.type) {
      case GET_USERS_REQUEST:
        return { ...state, loading: true };
      case GET_USERS_DATA:
        return { ...state, loading: false, users: action.payload, error: '' };
      case GET_USERS_ERROR:
        return { ...state, loading: false, users: [], error: action.payload };
      default:
        return state;
    }
  };

  export default reducer;