import axios from 'axios';

    const getUsersRequest = () => ({
    type: 'GET_USERS_REQUEST',
  });
  
    const getUsersData = (users) => ({
    type: 'GET_USERS_DATA',
    payload: users,
  });
  
    const getUsersError = (error) => ({
    type: 'GET_USERS_ERROR',
    payload: error,
  });

export const getUsers = () => {
    return function(dispatch){
        dispatch(getUsersRequest());
        axios.get("https://reqres.in/api/users?page=1")
        .then(res => dispatch(getUsersData(res.data.data)))
        .catch(error => dispatch(getUsersError(error)))
    }

}